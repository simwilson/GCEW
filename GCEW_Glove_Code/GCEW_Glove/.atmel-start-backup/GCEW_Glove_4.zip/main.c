#include <atmel_start.h>
#include <util/delay.h>
#include <string.h>
#include <stdio.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	sei();
	PRR0 &= ~(0 << PRADC); // Clearing Power Reduction Register Bit, when Set it shuts down the ADC
	uint16_t adc_read;
	char temp_string[60];

	while (1) {
		_delay_ms(1000);
		ADCSRA |= (1 << ADSC); // Set ADC Conversion Start Bit
		while ((ADCSRA & (1 << ADSC)) ) {}   // wait for ADC conversion to complete
		adc_read=ADC;

		sprintf(temp_string,"%u",adc_read); // Convert 10-bit ADC value (integer) to a string
		for (int i=0; i<strlen(temp_string); i++) // Loops to print character array pointed to by serial_temp
		{
			USART_0_write(temp_string[i]);
		}
		USART_0_write(10); // Prints new Line

	}
}
