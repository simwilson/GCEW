#include <atmel_start.h>
#include <avr/io.h>
#include <avr/sfr_defs.h>
#include <util/delay.h>
#include <stdio.h>
#include <string.h>
#include <usart_basic_example.h>
#include <usart_basic.h>
#include <atomic.h>

int main(void)
{
	/* Initializes MCU, drivers and Middleware */
	atmel_start_init();
	
	_delay_ms(1000);
	
	uint16_t x=1035;
	char test_string[] = "Testing"; 
	char temp_string[20];
	char *temp_serial_int = (char*) malloc(6); // creating /initialize a pointer to string that can holder 5 characters + nul terminator
	sprintf(temp_serial_int,"%u",x); // convert unsigned 16 bit int to a string and save it in memory location of serial_temp pointer
	


	while (1) {
		_delay_ms(500);
	
		for (int i=0; i<strlen(temp_serial_int); i++) // Loops to print character array pointed to by serial_temp
		{
			USART_0_write(temp_serial_int[i]);
		}

		USART_0_write(10); // Prints new line
		//*temp_serial_int=0;
		
		//PRR0 = (0 << PRADC);
		ADCSRA |= (1 << ADSC); 
		//_delay_ms(10);

		if ((ADCSRA & (1 << 6)) )
		{
			USART_0_write(35);
		}
		
		x=ADCL;

		sprintf(temp_string,"%u",x); 
		for (int i=0; i<strlen(temp_string); i++) // Loops to print character array pointed to by serial_temp
		{
			USART_0_write(temp_string[i]);
		}
		x=ADCH;
		USART_0_write(10); // Prints new line

		for (int i=0; i<strlen(test_string); i++) // Loops to print "Testing" array
		{
			USART_0_write(test_string[i]);
		}
		USART_0_write(10); // Prints new Line

		printf("Bit = %d",(ADMUX & (1 << 6)));
		USART_0_write(10);
		
	}
}


/*

*/