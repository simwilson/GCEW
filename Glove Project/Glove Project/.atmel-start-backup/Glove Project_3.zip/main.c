#include <atmel_start.h>
#include <pwm_basic.h>
#include <atomic.h>

volatile uint16_t         PWM_0_isr_executed_counter_1 = 0;
volatile PWM_0_register_t PWM_0_duty_1 = 0;

void PWM_0_pwm_handler_1(void)
{
	PWM_0_duty_1++;
	// Output duty cycle on PWM CH0
	PWM_0_load_duty_cycle_ch0(PWM_0_duty_1);
	PWM_0_isr_executed_counter_1++;
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	//--------------------------------------------
	// DO NOT REMOVE
	//--------------------------------------------
	atmel_start_init();
	
	DDRD = 0x04;
	
	// Enable pin output
	PWM_0_enable_output_ch0();

	// Set channel 0 duty cycle value register value to specified value
	PWM_0_load_duty_cycle_ch0(PWM_0_duty_1);

	// Set counter register value
	PWM_0_load_counter(0);

	// Test IRQ mode

	ENABLE_INTERRUPTS();

	PWM_0_register_callback(PWM_0_pwm_handler_1);

	// Wait for ISR to be executed 65000 times
	while (1)
	;

	return 1;
}



